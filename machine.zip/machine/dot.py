import joblib      
premodel = joblib.load('tfidf.pkl')
model = joblib.load('logistic_regression_model.pkl')

